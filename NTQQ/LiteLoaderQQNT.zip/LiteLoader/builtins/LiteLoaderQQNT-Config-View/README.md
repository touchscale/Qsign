# LiteLoaderQQNT-Config-View

LiteLoaderQQNT内置插件，LiteLoaderQQNT的配置界面

LiteLoaderQQNT本体：[LiteLoaderQQNT](https://github.com/LiteLoaderQQNT/LiteLoaderQQNT)

Telegram闲聊群：https://t.me/LiteLoaderQQNT
