// Electron 主进程 与 渲染进程 互相交互的桥梁
const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("config_view", {
    // 请求
    request: (url) => ipcRenderer.invoke("LiteLoader.config_view.request", url),
    // 获取系统代理
    getSystemProxy: () =>
        ipcRenderer.invoke("LiteLoader.config_view.getSystemProxy"),
    // 测试代理
    testProxy: (proxy) =>
        ipcRenderer.invoke("LiteLoader.config_view.testProxy", proxy),
    // 获取配置
    getConfig: () => ipcRenderer.invoke("LiteLoader.config_view.getConfig"),
    // 设置配置
    setConfig: (config) =>
        ipcRenderer.invoke("LiteLoader.config_view.setConfig", config),
    // 外部打开网址
    openWeb: (url) => ipcRenderer.send("LiteLoader.config_view.openWeb", url),
    // 显示目录选择框
    showPickDirDialog: () =>
        ipcRenderer.invoke("LiteLoader.config_view.showPickDirDialog"),
    // 显示数据目录
    showProfileDir: () =>
        ipcRenderer.invoke("LiteLoader.config_view.showProfileDir"),
    // 设置数据目录
    setProfilePath: (path) =>
        ipcRenderer.invoke("LiteLoader.config_view.setProfilePath", path),
    // 退出软件
    quit: () => ipcRenderer.invoke("LiteLoader.config_view.quit")
});
